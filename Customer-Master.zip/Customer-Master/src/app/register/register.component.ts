import { CustomerService } from './../customer.service';
import { CustomerModel } from './../models/Customer';
import { Component, Input, Output, EventEmitter } from '@angular/core';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent{

  @Input() customer : CustomerModel;

  @Input() isEditing:boolean;

  @Output() edited = new EventEmitter();

  constructor(private service:CustomerService) {
    this.customer=new CustomerModel();
    this.customer.gender="Male";
   }
   
   addCustomer(){
     this.service.addCustomer(this.customer);
     this.customer=new CustomerModel();
   }
   updateCustomer(){
    this.isEditing = false;
    this.customer = new CustomerModel();
    this.edited.emit();
   }
}
