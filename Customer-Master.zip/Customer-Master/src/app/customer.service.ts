import { CustomerModel } from './models/Customer';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  customers : CustomerModel[];
  constructor(private routes:Router) {
    this.customers=[];
   }
  addCustomer(cust:CustomerModel){
    cust.id= Math.floor(Math.random() * 1000);
    this.customers.push(cust);
    this.routes.navigate(['/display']);
  }
  getAllCustomers(){
    return this.customers;
  }
  delete(index: number) {
    this.customers.splice(index, 1);
  }
  edit(id:number){
    return this.customers.find(x => x.id == id);
  }
  search(id:number){
    var custResult = this.customers.find(x => x.id == id);
    if (custResult == null)
      return null; //if not found
    else
      return custResult; //if found then store it
  }
  sortById(){
    this.customers.sort((a,b)=> a.id>b.id ? 1 : a.id<b.id ? -1 : 0);
    return this.customers
  }
  sortByName(){
    this.customers.sort((a,b)=> a.name>b.name ? 1 : a.name<b.name ? -1 : 0);
    return this.customers
  }
}
