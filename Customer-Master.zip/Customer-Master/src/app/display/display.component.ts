import { CustomerService } from './../customer.service';
import { CustomerModel } from './../models/Customer';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {

  customers:CustomerModel[];
  isEditing:boolean;
  customeForEdit:CustomerModel;
  constructor(private service: CustomerService) {
    this.customers=[];
   }

  ngOnInit() {
    this.customers=this.service.getAllCustomers();
  }
  delete(index:number){
    this.service.delete(index);
  }
  edit(id:number){
    this.isEditing=true;
    this.customeForEdit=this.service.edit(id);
  }
  sortById(){
   this.service.sortById();
  }
  sortByName(){
    this.service.sortByName();
  }
}
