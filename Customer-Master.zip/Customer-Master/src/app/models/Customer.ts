export class CustomerModel{

    public id:number;
    public name:String;
    public gender:String;
    public email:string;
    public mobile:number;
    
}